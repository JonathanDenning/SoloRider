import java.util.Scanner;
import java.util.Random;

public class Suffix {

String[] suffix1=new String[11];
  String[] suffixDef=new String[11];
  Suffix(){

  suffix1[0]="ology";
  suffix1[1]="al";
  suffix1[2]="arium";
  suffix1[3]="phobic";
  suffix1[4]="ic";
  suffix1[5]="esque";
  suffix1[6]="ful";
  suffix1[7]="logue";
  suffix1[9]="oid";
  suffix[10]="ward";

  suffixDef[0]=" the study of ";
  suffixDef[1]=" pertaining to ";
  suffixDef[2]=" a habitiat for ";
  suffixDef[3]=" holding a fear of ";
  suffixDef[4]=" of or pertaining to ";
  suffixDef[5]=" in resemblence of ";
  suffixDef[6]=" characterized by ";
  suffixDef[7]=" of or pertaining to speech ";
  suffixDef[9]=" resembling, perhaps roughly ";
  suffixDef[10]=" indicating the direction of ";
  Scanner keyboard = new Scanner(System.in);
  String pre = "", preD = "", root = "", rootD = "", suffix = "", suffixD = "";

}

}