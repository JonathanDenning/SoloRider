import java.util.Scanner;
import java.util.Random;

public class Root {

  String[] rootDef =new String[11];
  String[] root1 = new String[11];
  Root(){

  
  root1[0]="chrono";
  root1[1]="jur";
  root1[2]="circ";
  root1[3]="acid";
  root1[4]="pend";
  root1[5]="heir";
  root1[6]="cardi";
  root1[7]="vers";
  root1[8]="astro";
  root1[9]="agri";
  root1[10]="milli";



  rootDef[0]=" of or pertaining to time ";
  rootDef[1]=" law ";
  rootDef[2]=" around ";
  rootDef[3]=" sour ";
  rootDef[4]=" hanging or weighing ";
  rootDef[5]=" succesor of ";
  rootDef[6]=" of or relating to the heart ";
  rootDef[7]=" turned ";
  rootDef[8]=" of or pertaining to stars ";
  rootDef[9]=" of or pertaining to agriculture ";
  rootDef[10]=" thousand ";

}

}