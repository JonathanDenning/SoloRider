import java.util.Scanner;
import java.util.Random;

public class Main {
   public static void main(String[] args){
    
     Scanner keyboard = new Scanner(System.in);
     System.out.println("welcom to the word creator");
     int tempr = keyboard.nextInt();
     if()
   } 
}