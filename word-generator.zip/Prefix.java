public class Prefix {
  String[] pre1 = new String[13];
  String[] preDef = new String[13];

  Prefix() {

    pre1[0] = "pre";
    pre1[1] = "re";
    pre1[2] = "semi";
    pre1[3] = "sub";
    pre1[4] = "pan";
    pre1[5] = "un";
    pre1[6] = "en";
    pre1[7] = "anti";
    pre1[8] = "pro";
    pre1[9] = "dis";
    pre1[10] = "a";
    pre1[11] = "ex";
    pre1[12] = "centi";

    preDef[0] = " before ";
    preDef[1] = " again ";
    preDef[2] = " partially ";
    preDef[3] = " under ";
    preDef[4] = " widespread ";
    preDef[5] = " not ";
    preDef[6] = " within ";
    preDef[7] = " against ";
    preDef[8] = " in support of ";
    preDef[9] = " apart ";
    preDef[10] = " not ";
    preDef[11] = " out of ";
    preDef[12] = " hundred ";

  }
  String returnPre(){
    return pre1[0];//replace zero with random number
  }
}